"""Statistical checks behind the headline findings.

Rows are subscriber-months, so several rows can belong to one person and are
not independent. Every confidence interval here therefore uses a *cluster
bootstrap* that resamples whole subscribers, instead of a naive row-level test.
"""
from __future__ import annotations

import json

import numpy as np
import pandas as pd
from scipy import stats

from . import config as cfg
from .data import load_panel

PRICE_MONTH_INDEX = 7  # matches data.generate_panel default


def _cluster_bootstrap_diff(df: pd.DataFrame, mask_a: pd.Series, mask_b: pd.Series,
                            n_boot: int = 1000, seed: int = cfg.RANDOM_STATE):
    """Difference in churn rate (A - B) with a subscriber-level bootstrap 95% CI."""
    rng = np.random.default_rng(seed)
    g = df[cfg.GROUP_COL].to_numpy()
    y = df[cfg.TARGET].to_numpy()
    a, b = mask_a.to_numpy(), mask_b.to_numpy()
    ids, inv = np.unique(g, return_inverse=True)
    # per-subscriber sufficient statistics
    n_a = np.bincount(inv, weights=a, minlength=len(ids))
    c_a = np.bincount(inv, weights=a * y, minlength=len(ids))
    n_b = np.bincount(inv, weights=b, minlength=len(ids))
    c_b = np.bincount(inv, weights=b * y, minlength=len(ids))

    point = c_a.sum() / n_a.sum() - c_b.sum() / n_b.sum()
    diffs = []
    for _ in range(n_boot):
        pick = rng.integers(0, len(ids), len(ids))
        diffs.append(c_a[pick].sum() / n_a[pick].sum() - c_b[pick].sum() / n_b[pick].sum())
    lo, hi = np.percentile(diffs, [2.5, 97.5])
    return {
        "rate_a": float(c_a.sum() / n_a.sum()),
        "rate_b": float(c_b.sum() / n_b.sum()),
        "difference": float(point),
        "ci95": [float(lo), float(hi)],
        "excludes_zero": bool(lo > 0 or hi < 0),
    }


def run_stats() -> dict:
    df = load_panel()
    out: dict = {}

    # 1) Was the price-increase month really unusual? ---------------------
    monthly = df.groupby(cfg.DATE_COL)[cfg.TARGET].agg(["mean", "size"])
    monthly.columns = ["churn_rate", "n_active"]
    months = monthly.index.sort_values()
    shock_month = months[PRICE_MONTH_INDEX]
    baseline = monthly.loc[months[:PRICE_MONTH_INDEX], "churn_rate"]
    z = (monthly.loc[shock_month, "churn_rate"] - baseline.mean()) / baseline.std(ddof=1)
    # exact binomial test against the pre-event pooled rate
    pre = df[df[cfg.DATE_COL] < shock_month]
    p0 = pre[cfg.TARGET].mean()
    shock_rows = df[df[cfg.DATE_COL] == shock_month]
    binom = stats.binomtest(int(shock_rows[cfg.TARGET].sum()), len(shock_rows), p0, alternative="greater")
    out["price_increase_spike"] = {
        "shock_month": str(shock_month.date()),
        "shock_month_churn_rate": float(monthly.loc[shock_month, "churn_rate"]),
        "pre_event_mean_rate": float(baseline.mean()),
        "pre_event_std_of_monthly_rate": float(baseline.std(ddof=1)),
        "z_score_vs_pre_event_months": float(z),
        "binomial_test_p_value": float(binom.pvalue),
        "ratio_to_pre_event_rate": float(monthly.loc[shock_month, "churn_rate"] / baseline.mean()),
    }
    monthly.reset_index().to_csv(cfg.TABLE_DIR / "monthly_churn.csv", index=False)

    # 2) Premium vs everyone else ----------------------------------------
    out["premium_vs_other_plans"] = _cluster_bootstrap_diff(
        df, df["plan_type"] == "Premium", df["plan_type"] != "Premium")

    # 3) New subscribers (<=3 months) vs loyal (>24 months) ----------------
    out["new_vs_loyal_subscribers"] = _cluster_bootstrap_diff(
        df, df["tenure_months"] <= 3, df["tenure_months"] > 24)

    # 4) Engagement decline: churn when watch time fell >30% vs not ------
    valid = df.dropna(subset=["engagement_trend"])
    out["engagement_decline_vs_stable"] = _cluster_bootstrap_diff(
        valid, valid["engagement_trend"] < 0.7, valid["engagement_trend"] >= 0.7)

    # 5) Dose-response: does churn fall as tenure grows? (Spearman) --------
    rho, p = stats.spearmanr(df["tenure_months"], df[cfg.TARGET])
    out["tenure_vs_churn_spearman"] = {"rho": float(rho), "p_value": float(p),
                                       "note": "row-level p-value is optimistic; see cluster CIs above"}

    cfg.STATS_PATH.write_text(json.dumps(out, indent=2))
    return out


if __name__ == "__main__":
    print(json.dumps(run_stats(), indent=2))
