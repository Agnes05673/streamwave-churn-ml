"""StreamWave churn prediction: data, EDA, modeling, evaluation, scoring."""

__version__ = "1.0.0"
