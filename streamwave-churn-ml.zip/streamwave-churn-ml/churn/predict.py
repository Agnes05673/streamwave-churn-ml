"""Batch scoring: turn a month of subscriber records into a ranked call list.

This is the "weekly batch scoring" deployment described in the project plan:
load the saved model, score every active subscriber, flag those above the
cost-optimal threshold, and hand the retention team the riskiest first.
"""
from __future__ import annotations

import json

import joblib
import pandas as pd

from . import config as cfg


def load_model():
    if not cfg.MODEL_PATH.exists():
        raise FileNotFoundError("No trained model found. Run `python -m churn train` first.")
    model = joblib.load(cfg.MODEL_PATH)
    card = json.loads(cfg.MODEL_CARD_PATH.read_text())
    return model, card


def score_subscribers(df: pd.DataFrame, model=None, threshold: float | None = None,
                      top_n: int | None = None) -> pd.DataFrame:
    """Return `df` with churn_probability, risk_rank and flagged columns, riskiest first."""
    if model is None or threshold is None:
        model, card = load_model()
        threshold = card["threshold"] if threshold is None else threshold
    missing = [c for c in cfg.FEATURES if c not in df.columns]
    if missing:
        raise ValueError(f"Input is missing required feature columns: {missing}")

    out = df.copy()
    out["churn_probability"] = model.predict_proba(out[cfg.FEATURES])[:, 1]
    out = out.sort_values("churn_probability", ascending=False).reset_index(drop=True)
    out["risk_rank"] = out.index + 1
    out["flagged"] = (out["churn_probability"] >= threshold).astype(int)
    return out.head(top_n) if top_n else out
