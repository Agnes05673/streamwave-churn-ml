"""Model selection and training.

Steps
1. Split by *subscriber* (not by row) so no person appears in both train and test.
2. Compare a naive baseline, logistic regression, random forest and gradient
   boosting with stratified, group-aware k-fold cross-validation.
3. Tune the best tree-based candidate with randomized search.
4. Choose the decision threshold from out-of-fold predictions and the business
   cost of a missed churner versus a wasted retention offer (never from test data).
5. Refit on all training data and save the model plus a model card.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone

import joblib
import numpy as np
import pandas as pd
import sklearn
from scipy.stats import loguniform
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import (
    GroupShuffleSplit,
    RandomizedSearchCV,
    StratifiedGroupKFold,
    cross_val_predict,
    cross_validate,
)
from sklearn.pipeline import Pipeline

from . import config as cfg
from .data import load_panel, validate_panel
from .features import build_preprocessor

SCORING = {"roc_auc": "roc_auc", "pr_auc": "average_precision", "brier": "neg_brier_score"}


# ---------------------------------------------------------------------------
# Splitting
# ---------------------------------------------------------------------------
def split_by_subscriber(df: pd.DataFrame, test_size: float = 0.25, seed: int = cfg.RANDOM_STATE):
    """Return (train_df, test_df) with disjoint subscribers."""
    splitter = GroupShuffleSplit(n_splits=1, test_size=test_size, random_state=seed)
    train_idx, test_idx = next(splitter.split(df, groups=df[cfg.GROUP_COL]))
    return df.iloc[train_idx].reset_index(drop=True), df.iloc[test_idx].reset_index(drop=True)


def make_cv(n_splits: int = 5, seed: int = cfg.RANDOM_STATE) -> StratifiedGroupKFold:
    return StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)


# ---------------------------------------------------------------------------
# Candidate models
# ---------------------------------------------------------------------------
def build_candidates(seed: int = cfg.RANDOM_STATE) -> dict[str, Pipeline]:
    # No class re-weighting on purpose: it inflates predicted probabilities. We keep
    # probabilities honest and handle the class imbalance through the cost-based
    # decision threshold instead (see choose_threshold).
    estimators = {
        "Baseline (class prior)": DummyClassifier(strategy="prior"),
        "Logistic Regression": LogisticRegression(max_iter=2000),
        "Random Forest": RandomForestClassifier(
            n_estimators=300, min_samples_leaf=20, n_jobs=-1, random_state=seed),
        "Gradient Boosting": HistGradientBoostingClassifier(random_state=seed),
    }
    return {name: Pipeline([("pre", build_preprocessor()), ("clf", est)])
            for name, est in estimators.items()}


SEARCH_SPACES = {
    "Logistic Regression": {"clf__C": loguniform(1e-3, 1e2)},
    "Random Forest": {
        "clf__max_depth": [4, 6, 8, 12, None],
        "clf__min_samples_leaf": [10, 20, 50, 100],
        "clf__max_features": ["sqrt", 0.5, 0.8],
    },
    "Gradient Boosting": {
        "clf__learning_rate": loguniform(0.02, 0.2),
        "clf__max_leaf_nodes": [8, 15, 31],
        "clf__min_samples_leaf": [20, 50, 100],
        "clf__l2_regularization": loguniform(1e-3, 10),
        "clf__max_iter": [150, 250, 400],
    },
}


def compare_models(X, y, groups, n_splits: int = 5) -> pd.DataFrame:
    """Cross-validate every candidate; return mean ± std for each metric."""
    rows = []
    for name, pipe in build_candidates().items():
        res = cross_validate(pipe, X, y, groups=groups, cv=make_cv(n_splits),
                             scoring=SCORING, n_jobs=1)
        rows.append({
            "model": name,
            "roc_auc_mean": res["test_roc_auc"].mean(), "roc_auc_std": res["test_roc_auc"].std(),
            "pr_auc_mean": res["test_pr_auc"].mean(), "pr_auc_std": res["test_pr_auc"].std(),
            "brier_mean": -res["test_brier"].mean(),
            "fit_seconds": res["fit_time"].mean(),
        })
        print(f"  {name:<24} ROC-AUC {rows[-1]['roc_auc_mean']:.3f} ± {rows[-1]['roc_auc_std']:.3f}"
              f" | PR-AUC {rows[-1]['pr_auc_mean']:.3f}")
    return pd.DataFrame(rows).sort_values("pr_auc_mean", ascending=False).reset_index(drop=True)


# ---------------------------------------------------------------------------
# Tuning and threshold
# ---------------------------------------------------------------------------
def tune(best_name: str, X, y, groups, n_iter: int = 15, seed: int = cfg.RANDOM_STATE):
    """Randomized search on PR-AUC (better than accuracy for a rare positive class)."""
    pipe = build_candidates()[best_name]
    search = RandomizedSearchCV(
        pipe, SEARCH_SPACES[best_name], n_iter=n_iter, scoring="average_precision",
        cv=make_cv(3, seed), random_state=seed, n_jobs=-1, refit=True,
    )
    search.fit(X, y, groups=groups)
    return search


def cost_at_threshold(y_true, proba, threshold: float,
                      cost_fn: float = cfg.COST_FALSE_NEGATIVE,
                      cost_fp: float = cfg.COST_FALSE_POSITIVE) -> float:
    pred = proba >= threshold
    fn = np.sum((y_true == 1) & ~pred)
    fp = np.sum((y_true == 0) & pred)
    return float(fn * cost_fn + fp * cost_fp)


def choose_threshold(y_true, proba, cost_fn: float = cfg.COST_FALSE_NEGATIVE,
                     cost_fp: float = cfg.COST_FALSE_POSITIVE) -> tuple[float, pd.DataFrame]:
    """Pick the probability cutoff that minimises expected business cost."""
    y_true = np.asarray(y_true)
    grid = np.linspace(0.01, 0.99, 99)
    costs = np.array([cost_at_threshold(y_true, proba, t, cost_fn, cost_fp) for t in grid])
    curve = pd.DataFrame({"threshold": grid, "expected_cost": costs})
    return float(grid[costs.argmin()]), curve


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------
def run_training(n_iter: int = 15) -> dict:
    cfg.MODELS_DIR.mkdir(parents=True, exist_ok=True)
    cfg.TABLE_DIR.mkdir(parents=True, exist_ok=True)

    df = load_panel()
    validate_panel(df)
    train_df, test_df = split_by_subscriber(df)
    assert set(train_df[cfg.GROUP_COL]).isdisjoint(test_df[cfg.GROUP_COL]), "subscriber leakage!"
    print(f"Train: {len(train_df):,} rows / {train_df[cfg.GROUP_COL].nunique():,} subscribers | "
          f"Test: {len(test_df):,} rows / {test_df[cfg.GROUP_COL].nunique():,} subscribers")

    X, y, groups = train_df[cfg.FEATURES], train_df[cfg.TARGET], train_df[cfg.GROUP_COL]

    print("\n[1/4] Cross-validated model comparison (5-fold, grouped by subscriber)")
    comparison = compare_models(X, y, groups)
    comparison.to_csv(cfg.TABLE_DIR / "model_comparison.csv", index=False)

    tunable = comparison[comparison["model"].isin(SEARCH_SPACES)]
    best_name = tunable.iloc[0]["model"]
    print(f"\n[2/4] Tuning '{best_name}' ({n_iter} random configurations, PR-AUC)")
    search = tune(best_name, X, y, groups, n_iter=n_iter)
    shown = {k: (round(float(v), 4) if isinstance(v, (int, float, np.number)) else v)
             for k, v in search.best_params_.items()}
    print(f"  best CV PR-AUC {search.best_score_:.3f}  params: {shown}")

    print("\n[3/4] Choosing decision threshold from out-of-fold predictions")
    oof = cross_val_predict(search.best_estimator_, X, y, groups=groups, cv=make_cv(5),
                            method="predict_proba")[:, 1]
    threshold, curve = choose_threshold(y, oof)
    curve.to_csv(cfg.TABLE_DIR / "threshold_cost_curve.csv", index=False)
    theoretical = cfg.COST_FALSE_POSITIVE / (cfg.COST_FALSE_POSITIVE + cfg.COST_FALSE_NEGATIVE)
    print(f"  chosen threshold = {threshold:.2f} | theoretical optimum for perfectly calibrated "
          f"probabilities = {theoretical:.3f}")

    print("\n[4/4] Saving model")
    model = search.best_estimator_
    joblib.dump(model, cfg.MODEL_PATH)
    card = {
        "trained_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "model": best_name,
        "best_params": {k: (float(v) if isinstance(v, (np.floating, float)) else
                            (int(v) if isinstance(v, (np.integer,)) else v))
                        for k, v in search.best_params_.items()},
        "threshold": threshold,
        "theoretical_threshold_if_calibrated": theoretical,
        "cv_pr_auc_tuned": float(search.best_score_),
        "features": cfg.FEATURES,
        "train_rows": int(len(train_df)),
        "train_churn_rate": float(y.mean()),
        "sklearn_version": sklearn.__version__,
        "cost_false_negative": cfg.COST_FALSE_NEGATIVE,
        "cost_false_positive": cfg.COST_FALSE_POSITIVE,
        "note": "Trained on synthetic data; illustrative only.",
    }
    cfg.MODEL_CARD_PATH.write_text(json.dumps(card, indent=2))
    return card


if __name__ == "__main__":
    run_training()
