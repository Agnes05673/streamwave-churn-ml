"""Central configuration: paths, column names, and business assumptions."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
MODELS_DIR = ROOT / "models"
OUTPUT_DIR = ROOT / "outputs"
FIG_DIR = OUTPUT_DIR / "figures"
TABLE_DIR = OUTPUT_DIR / "tables"

RANDOM_STATE = 42

# --- Schema -----------------------------------------------------------------
TARGET = "churned"            # 1 = subscriber cancelled at the end of this month
GROUP_COL = "subscriber_id"   # rows from one subscriber must never straddle train/test
DATE_COL = "month"

NUMERIC_FEATURES = [
    "tenure_months",
    "monthly_price",
    "watch_hours",
    "engagement_trend",       # this month's watch time / trailing average
    "support_tickets_30d",
]
BINARY_FEATURES = ["billing_ticket_recent", "price_increase_recent"]
CATEGORICAL_FEATURES = ["plan_type"]
FEATURES = NUMERIC_FEATURES + BINARY_FEATURES + CATEGORICAL_FEATURES

# --- Business assumptions (used only to pick the decision threshold) ---------
# Missing a churner loses roughly this much future margin ($).
COST_FALSE_NEGATIVE = 60.0
# A wasted retention offer to someone who would have stayed costs this much ($).
COST_FALSE_POSITIVE = 5.0

# Retention team capacity: fraction of subscribers they can contact each month.
TOP_FRACTION = 0.10

# --- File locations ------------------------------------------------------------
PANEL_PATH = DATA_DIR / "subscriber_months.csv"
MODEL_PATH = MODELS_DIR / "churn_model.joblib"
MODEL_CARD_PATH = MODELS_DIR / "model_card.json"
METRICS_PATH = OUTPUT_DIR / "metrics.json"
STATS_PATH = OUTPUT_DIR / "stats_checks.json"
