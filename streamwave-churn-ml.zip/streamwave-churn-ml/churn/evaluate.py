"""Held-out evaluation: metrics, curves, business lift, and feature importance."""
from __future__ import annotations

import json

import joblib
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.calibration import calibration_curve
from sklearn.inspection import permutation_importance
from sklearn.metrics import (
    ConfusionMatrixDisplay,
    accuracy_score,
    average_precision_score,
    brier_score_loss,
    f1_score,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)

from . import config as cfg
from .data import load_panel
from .train import cost_at_threshold, split_by_subscriber

NAVY, TEAL, ORANGE, GREY = "#2E4A6B", "#3E7C8C", "#C97B4A", "#9AA6B2"


def _style(ax):
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(color="#E3E7EC", linewidth=0.8)
    ax.set_axisbelow(True)


def top_fraction_lift(y_true: np.ndarray, proba: np.ndarray, fraction: float) -> dict:
    """How many churners do we catch by contacting only the riskiest `fraction`?"""
    n_top = max(1, int(round(len(y_true) * fraction)))
    order = np.argsort(-proba)[:n_top]
    caught = y_true[order].sum()
    base_rate = y_true.mean()
    return {
        "fraction_contacted": fraction,
        "subscribers_contacted": int(n_top),
        "churners_caught": int(caught),
        "share_of_all_churners_caught": float(caught / y_true.sum()),
        "precision_in_top_group": float(caught / n_top),
        "lift_vs_random": float((caught / n_top) / base_rate),
    }


def cluster_bootstrap_ci(y_true, proba, groups, metric, n_boot: int = 300, seed: int = cfg.RANDOM_STATE):
    """95% CI that resamples whole subscribers (rows from one person are correlated)."""
    rng = np.random.default_rng(seed)
    idx_by_group = pd.Series(np.arange(len(groups))).groupby(np.asarray(groups)).apply(np.array)
    ids = idx_by_group.index.to_numpy()
    vals = []
    for _ in range(n_boot):
        chosen = rng.choice(ids, size=len(ids), replace=True)
        idx = np.concatenate([idx_by_group[g] for g in chosen])
        if y_true[idx].min() == y_true[idx].max():
            continue
        vals.append(metric(y_true[idx], proba[idx]))
    return float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))


def run_evaluation() -> dict:
    cfg.FIG_DIR.mkdir(parents=True, exist_ok=True)
    cfg.TABLE_DIR.mkdir(parents=True, exist_ok=True)

    model = joblib.load(cfg.MODEL_PATH)
    card = json.loads(cfg.MODEL_CARD_PATH.read_text())
    threshold = card["threshold"]

    _, test_df = split_by_subscriber(load_panel())
    X, y = test_df[cfg.FEATURES], test_df[cfg.TARGET].to_numpy()
    groups = test_df[cfg.GROUP_COL].to_numpy()
    proba = model.predict_proba(X)[:, 1]
    pred = (proba >= threshold).astype(int)

    base_rate = float(y.mean())
    roc_ci = cluster_bootstrap_ci(y, proba, groups, roc_auc_score)
    pr_ci = cluster_bootstrap_ci(y, proba, groups, average_precision_score)
    cost_model = cost_at_threshold(y, proba, threshold)
    cost_no_model = float(y.sum() * cfg.COST_FALSE_NEGATIVE)              # contact nobody
    cost_contact_all = float((len(y) - y.sum()) * cfg.COST_FALSE_POSITIVE)  # offer to everyone

    metrics = {
        "test_rows": int(len(y)),
        "test_subscribers": int(len(np.unique(groups))),
        "test_churn_rate": base_rate,
        "threshold": threshold,
        "roc_auc": float(roc_auc_score(y, proba)),
        "roc_auc_95ci": roc_ci,
        "pr_auc": float(average_precision_score(y, proba)),
        "pr_auc_95ci": pr_ci,
        "pr_auc_random_baseline": base_rate,
        "brier_score": float(brier_score_loss(y, proba)),
        "at_threshold": {
            "accuracy": float(accuracy_score(y, pred)),
            "precision": float(precision_score(y, pred, zero_division=0)),
            "recall": float(recall_score(y, pred)),
            "f1": float(f1_score(y, pred)),
            "flagged_share": float(pred.mean()),
        },
        "top_fraction": top_fraction_lift(y, proba, cfg.TOP_FRACTION),
        "expected_cost_usd": {
            "with_model": cost_model,
            "contact_nobody": cost_no_model,
            "contact_everybody": cost_contact_all,
        },
    }
    cfg.METRICS_PATH.write_text(json.dumps(metrics, indent=2))

    # ---- Figure 1: ROC + PR ------------------------------------------------
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.6))
    fpr, tpr, _ = roc_curve(y, proba)
    axes[0].plot(fpr, tpr, color=TEAL, lw=2.5, label=f"Model (AUC {metrics['roc_auc']:.2f})")
    axes[0].plot([0, 1], [0, 1], "--", color=GREY, label="Random (AUC 0.50)")
    axes[0].set(xlabel="False positive rate", ylabel="True positive rate", title="ROC curve (test set)")
    axes[0].legend(loc="lower right")
    prec, rec, _ = precision_recall_curve(y, proba)
    axes[1].plot(rec, prec, color=ORANGE, lw=2.5, label=f"Model (PR-AUC {metrics['pr_auc']:.2f})")
    axes[1].axhline(base_rate, ls="--", color=GREY, label=f"Random ({base_rate:.3f})")
    axes[1].set(xlabel="Recall", ylabel="Precision", title="Precision-recall curve (test set)",
                ylim=(0, 1.02))
    axes[1].legend(loc="upper right")
    for ax in axes:
        _style(ax)
    fig.tight_layout()
    fig.savefig(cfg.FIG_DIR / "eval_roc_pr.png", dpi=200)
    plt.close(fig)

    # ---- Figure 2: confusion matrix + calibration -------------------------
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.6))
    ConfusionMatrixDisplay.from_predictions(
        y, pred, display_labels=["Retained", "Churned"], cmap="Blues", colorbar=False, ax=axes[0])
    axes[0].set_title(f"Confusion matrix at threshold {threshold:.2f}")
    frac_pos, mean_pred = calibration_curve(y, proba, n_bins=10, strategy="quantile")
    axes[1].plot(mean_pred, frac_pos, "o-", color=NAVY, lw=2, label="Model")
    axes[1].plot([0, max(mean_pred.max(), frac_pos.max())], [0, max(mean_pred.max(), frac_pos.max())],
                 "--", color=GREY, label="Perfectly calibrated")
    axes[1].set(xlabel="Predicted churn probability", ylabel="Observed churn rate",
                title="Calibration (test set)")
    axes[1].legend()
    _style(axes[1])
    fig.tight_layout()
    fig.savefig(cfg.FIG_DIR / "eval_confusion_calibration.png", dpi=200)
    plt.close(fig)

    # ---- Figure 3: cumulative gains (business view) -----------------------
    order = np.argsort(-proba)
    gains = np.cumsum(y[order]) / y.sum()
    share = np.arange(1, len(y) + 1) / len(y)
    fig, ax = plt.subplots(figsize=(6.5, 4.8))
    ax.plot(share, gains, color=TEAL, lw=2.5, label="Model ranking")
    ax.plot([0, 1], [0, 1], "--", color=GREY, label="Random outreach")
    ax.axvline(cfg.TOP_FRACTION, color=ORANGE, ls=":", lw=1.5)
    t = metrics["top_fraction"]
    ax.annotate(f"Top {cfg.TOP_FRACTION:.0%} contacted\ncatches {t['share_of_all_churners_caught']:.0%} of churners",
                (cfg.TOP_FRACTION, t["share_of_all_churners_caught"]),
                xytext=(0.28, 0.42), arrowprops=dict(arrowstyle="->", color=ORANGE), color=ORANGE)
    ax.set(xlabel="Share of subscribers contacted (riskiest first)",
           ylabel="Share of all churners caught", title="Cumulative gains (test set)")
    ax.legend(loc="lower right")
    _style(ax)
    fig.tight_layout()
    fig.savefig(cfg.FIG_DIR / "eval_cumulative_gains.png", dpi=200)
    plt.close(fig)

    # ---- Permutation importance (on raw columns, so it's interpretable) ----
    sample = test_df.sample(n=min(6000, len(test_df)), random_state=cfg.RANDOM_STATE)
    pi = permutation_importance(model, sample[cfg.FEATURES], sample[cfg.TARGET],
                                scoring="average_precision", n_repeats=8,
                                random_state=cfg.RANDOM_STATE, n_jobs=-1)
    imp = (pd.DataFrame({"feature": cfg.FEATURES, "importance_mean": pi.importances_mean,
                         "importance_std": pi.importances_std})
           .sort_values("importance_mean", ascending=False).reset_index(drop=True))
    imp.to_csv(cfg.TABLE_DIR / "permutation_importance.csv", index=False)

    fig, ax = plt.subplots(figsize=(7.5, 4.6))
    top = imp.iloc[::-1]
    ax.barh(top["feature"], top["importance_mean"], xerr=top["importance_std"],
            color=TEAL, edgecolor="white")
    ax.set(xlabel="Drop in PR-AUC when the feature is shuffled",
           title="Permutation importance (test sample)")
    _style(ax)
    fig.tight_layout()
    fig.savefig(cfg.FIG_DIR / "eval_permutation_importance.png", dpi=200)
    plt.close(fig)

    return metrics


if __name__ == "__main__":
    print(json.dumps(run_evaluation(), indent=2))
