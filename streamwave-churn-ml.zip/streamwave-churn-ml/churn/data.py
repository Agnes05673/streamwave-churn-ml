"""Synthetic subscriber-month data: generation, loading, and validation.

No real data is used anywhere in this project. The simulator builds a panel
(one row per active subscriber per month) in which churn depends on
engagement decline, tenure, support friction, plan, and a one-off price
increase. Because the monthly trend, segment rates, and model training data
all come from the same rows, every downstream number is internally consistent.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from . import config as cfg

PLAN_NAMES = ["Basic", "Standard", "Premium"]
PLAN_PRICE = {"Basic": 8.99, "Standard": 13.99, "Premium": 17.99}
PLAN_PRICE_INCREASE = {"Basic": 0.0, "Standard": 1.0, "Premium": 2.0}

# How strongly a price increase pushes churn up in the month it lands and after.
PRICE_SHOCK_BY_LAG = {0: 1.15, 1: 0.65, 2: 0.25}

EXPECTED_COLUMNS = [
    cfg.GROUP_COL, cfg.DATE_COL, "plan_type", "tenure_months", "monthly_price",
    "watch_hours", "engagement_trend", "support_tickets_30d",
    "billing_ticket_recent", "price_increase_recent", cfg.TARGET,
]


def generate_panel(
    n_initial: int = 3000,
    n_months: int = 12,
    n_new_per_month: int = 220,
    price_month: int = 7,
    start: str = "2025-09-01",
    seed: int = cfg.RANDOM_STATE,
) -> pd.DataFrame:
    """Simulate `n_months` of subscriber activity.

    `price_month` is the zero-based month index in which Standard/Premium
    prices rise. Subscribers who cancel leave the panel; new ones join.
    """
    rng = np.random.default_rng(seed)

    def new_subscribers(n: int, first_id: int, existing: bool):
        plan = rng.choice(PLAN_NAMES, size=n, p=[0.33, 0.42, 0.25])
        tenure = (rng.gamma(2.0, 10.0, n) if existing else np.full(n, 0.5)).clip(0.5, 72)
        base_watch = rng.normal(15, 5, n).clip(3, None)
        return {
            "id": np.arange(first_id, first_id + n),
            "plan": plan,
            "tenure": tenure,
            "base_watch": base_watch,
            "level": np.zeros(n),          # log-scale drift in viewing habits
            "trail": base_watch.copy(),    # trailing average of watch hours
        }

    state = new_subscribers(n_initial, 0, existing=True)
    next_id = n_initial
    frames = []

    for m in range(n_months):
        n = len(state["id"])
        plan = state["plan"]
        month = pd.Timestamp(start) + pd.DateOffset(months=m)

        state["level"] = state["level"] + rng.normal(-0.01, 0.16, n)
        watch = state["base_watch"] * np.exp(state["level"])
        trend = watch / state["trail"]

        lag = m - price_month
        in_shock_window = lag in PRICE_SHOCK_BY_LAG
        billing_p = 0.16 if in_shock_window else 0.07
        billing = rng.random(n) < billing_p
        tickets = rng.poisson(0.7, n)

        price_up = np.array([PLAN_PRICE_INCREASE[p] for p in plan])
        base_price = np.array([PLAN_PRICE[p] for p in plan])
        price = base_price + (price_up if lag >= 0 else 0.0)
        price_recent = (in_shock_window) & (price_up > 0)

        shock = PRICE_SHOCK_BY_LAG.get(lag, 0.0) * (price_up > 0) * (0.8 + 0.2 * price_up)

        logit = (
            -3.35
            + 2.6 * np.clip(1 - trend, -0.5, 1.0)
            + 1.5 * np.exp(-state["tenure"] / 5.0)
            - 0.012 * np.minimum(state["tenure"], 48)
            - 0.03 * watch
            + 0.28 * tickets
            + 0.9 * billing
            + 0.35 * (plan == "Premium")
            + shock
            + rng.normal(0, 0.3, n)
        )
        churned = rng.random(n) < 1 / (1 + np.exp(-logit))

        frames.append(pd.DataFrame({
            cfg.GROUP_COL: state["id"],
            cfg.DATE_COL: month,
            "plan_type": plan,
            "tenure_months": state["tenure"].round(1),
            "monthly_price": price.round(2),
            "watch_hours": watch.round(1),
            "engagement_trend": trend.round(3),
            "support_tickets_30d": tickets,
            "billing_ticket_recent": billing.astype(int),
            "price_increase_recent": price_recent.astype(int),
            cfg.TARGET: churned.astype(int),
        }))

        # advance one month: survivors age, habits update, newcomers join
        keep = ~churned
        state = {k: v[keep] for k, v in state.items()}
        state["tenure"] = state["tenure"] + 1
        state["trail"] = 0.7 * state["trail"] + 0.3 * (watch[keep])
        fresh = new_subscribers(n_new_per_month, next_id, existing=False)
        next_id += n_new_per_month
        state = {k: np.concatenate([state[k], fresh[k]]) for k in state}

    df = pd.concat(frames, ignore_index=True)
    return _inject_data_quality_issues(df, rng)


def _inject_data_quality_issues(df: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    """Add realistic messiness so the preprocessing code has real work to do."""
    df = df.copy()
    miss = rng.random(len(df)) < 0.03           # ~3% of viewing records missing
    df.loc[miss, ["watch_hours", "engagement_trend"]] = np.nan
    tick_miss = rng.random(len(df)) < 0.01
    df["support_tickets_30d"] = df["support_tickets_30d"].astype(float)
    df.loc[tick_miss, "support_tickets_30d"] = np.nan
    outliers = rng.random(len(df)) < 0.001      # a few implausible ticket counts
    df.loc[outliers, "support_tickets_30d"] = rng.integers(20, 40, outliers.sum())
    return df


def save_panel(df: pd.DataFrame, path=cfg.PANEL_PATH) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def load_panel(path=cfg.PANEL_PATH) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(
            f"{path} not found. Run `python -m churn generate` first."
        )
    return pd.read_csv(path, parse_dates=[cfg.DATE_COL])


def validate_panel(df: pd.DataFrame) -> dict:
    """Return a dict of data-quality findings; raise on structural problems."""
    missing_cols = [c for c in EXPECTED_COLUMNS if c not in df.columns]
    if missing_cols:
        raise ValueError(f"Missing required columns: {missing_cols}")
    if not set(df[cfg.TARGET].unique()) <= {0, 1}:
        raise ValueError("Target must be binary (0/1).")
    if (df["tenure_months"] < 0).any():
        raise ValueError("Negative tenure values found.")
    if not set(df["plan_type"].unique()) <= set(PLAN_NAMES):
        raise ValueError("Unknown plan_type values found.")
    return {
        "rows": int(len(df)),
        "subscribers": int(df[cfg.GROUP_COL].nunique()),
        "months": int(df[cfg.DATE_COL].nunique()),
        "churn_rate": float(df[cfg.TARGET].mean()),
        "missing_by_column": {k: int(v) for k, v in df.isna().sum().items() if v > 0},
        "duplicate_subscriber_months": int(df.duplicated([cfg.GROUP_COL, cfg.DATE_COL]).sum()),
    }
