"""Preprocessing: everything that turns raw columns into model-ready arrays.

All fitted steps (imputer medians, scaler statistics, outlier caps, category
levels) live inside a scikit-learn Pipeline, so they are learned from the
training fold only and cannot leak information from validation or test rows.
"""
from __future__ import annotations

import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from . import config as cfg


class QuantileClipper(BaseEstimator, TransformerMixin):
    """Winsorize each numeric column to the [lower, upper] training quantiles.

    Handles implausible values (e.g. 35 support tickets in a month) without
    dropping rows. NaNs pass through untouched so the imputer can handle them.
    """

    def __init__(self, lower: float = 0.001, upper: float = 0.999):
        self.lower = lower
        self.upper = upper

    def fit(self, X, y=None):
        X = np.asarray(X, dtype=float)
        self.low_ = np.nanquantile(X, self.lower, axis=0)
        self.high_ = np.nanquantile(X, self.upper, axis=0)
        return self

    def transform(self, X):
        X = np.asarray(X, dtype=float)
        return np.clip(X, self.low_, self.high_)

    def get_feature_names_out(self, input_features=None):
        return np.asarray(input_features, dtype=object)


def build_preprocessor() -> ColumnTransformer:
    numeric = Pipeline([
        ("clip", QuantileClipper()),
        # add_indicator keeps "was this value missing?" as its own signal
        ("impute", SimpleImputer(strategy="median", add_indicator=True)),
        ("scale", StandardScaler()),
    ])
    binary = SimpleImputer(strategy="most_frequent")
    categorical = OneHotEncoder(handle_unknown="ignore")

    return ColumnTransformer(
        [
            ("num", numeric, cfg.NUMERIC_FEATURES),
            ("bin", binary, cfg.BINARY_FEATURES),
            ("cat", categorical, cfg.CATEGORICAL_FEATURES),
        ],
        verbose_feature_names_out=False,
    )


def feature_names(fitted_preprocessor: ColumnTransformer) -> list[str]:
    """Readable output column names after fitting (incl. missing-value flags)."""
    names: list[str] = []
    num_pipe = fitted_preprocessor.named_transformers_["num"]
    imputer = num_pipe.named_steps["impute"]
    names += list(cfg.NUMERIC_FEATURES)
    names += [f"{cfg.NUMERIC_FEATURES[i]}__was_missing" for i in imputer.indicator_.features_]
    names += list(cfg.BINARY_FEATURES)
    names += list(fitted_preprocessor.named_transformers_["cat"].get_feature_names_out(cfg.CATEGORICAL_FEATURES))
    return names
