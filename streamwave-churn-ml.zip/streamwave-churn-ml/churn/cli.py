"""Command-line entry point: `python -m churn <command>`."""
from __future__ import annotations

import argparse
import json

from . import config as cfg


def main(argv=None) -> None:
    p = argparse.ArgumentParser(prog="churn", description="StreamWave churn pipeline")
    sub = p.add_subparsers(dest="command", required=True)

    sub.add_parser("generate", help="simulate the subscriber-month dataset")
    sub.add_parser("eda", help="quality audit + exploratory plots/tables")
    t = sub.add_parser("train", help="compare, tune and save a model")
    t.add_argument("--n-iter", type=int, default=15, help="random-search configurations")
    sub.add_parser("evaluate", help="held-out test metrics and plots")
    sub.add_parser("stats", help="statistical checks behind the headline findings")
    pr = sub.add_parser("predict", help="score the latest month and write a ranked call list")
    pr.add_argument("--top", type=int, default=500, help="rows to keep in the output list")
    pr.add_argument("--output", default=str(cfg.OUTPUT_DIR / "at_risk_subscribers.csv"))
    sub.add_parser("all", help="run every step in order")

    args = p.parse_args(argv)
    cmd = args.command

    if cmd in ("generate", "all"):
        from .data import generate_panel, save_panel, validate_panel
        df = generate_panel()
        save_panel(df)
        print("Generated dataset:", json.dumps(validate_panel(df), indent=2))
    if cmd in ("eda", "all"):
        from .eda import run_eda
        run_eda()
        print("EDA figures/tables written to", cfg.OUTPUT_DIR)
    if cmd in ("train", "all"):
        from .train import run_training
        run_training(n_iter=getattr(args, "n_iter", 15))
    if cmd in ("evaluate", "all"):
        from .evaluate import run_evaluation
        m = run_evaluation()
        print(f"Test ROC-AUC {m['roc_auc']:.3f} | PR-AUC {m['pr_auc']:.3f} "
              f"(random {m['pr_auc_random_baseline']:.3f})")
    if cmd in ("stats", "all"):
        from .stats_checks import run_stats
        run_stats()
        print("Statistical checks written to", cfg.STATS_PATH)
    if cmd in ("predict", "all"):
        from .data import load_panel
        from .predict import score_subscribers
        df = load_panel()
        latest = df[df[cfg.DATE_COL] == df[cfg.DATE_COL].max()].drop(columns=[cfg.TARGET])
        top = getattr(args, "top", 500)
        out_path = getattr(args, "output", str(cfg.OUTPUT_DIR / "at_risk_subscribers.csv"))
        scored = score_subscribers(latest, top_n=top)
        scored.to_csv(out_path, index=False)
        print(f"Scored {len(latest):,} subscribers; top {len(scored)} written to {out_path}")


if __name__ == "__main__":
    main()
