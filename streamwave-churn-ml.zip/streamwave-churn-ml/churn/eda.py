"""Exploratory data analysis: quality audit, distributions, segments, trends."""
from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

from . import config as cfg
from .data import load_panel, validate_panel

NAVY, TEAL, ORANGE, GREY = "#2E4A6B", "#3E7C8C", "#C97B4A", "#9AA6B2"


def _clean(ax):
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", color="#E3E7EC", linewidth=0.8)
    ax.set_axisbelow(True)


def quality_audit(df: pd.DataFrame) -> pd.DataFrame:
    """Missing values, unique counts, and IQR-rule outlier counts per column."""
    rows = []
    for col in cfg.NUMERIC_FEATURES:
        s = df[col].dropna()
        q1, q3 = s.quantile([0.25, 0.75])
        iqr = q3 - q1
        outliers = ((s < q1 - 1.5 * iqr) | (s > q3 + 1.5 * iqr)).sum()
        rows.append({"column": col, "missing": int(df[col].isna().sum()),
                     "missing_pct": round(100 * df[col].isna().mean(), 2),
                     "min": s.min(), "median": s.median(), "max": s.max(),
                     "iqr_outliers": int(outliers)})
    return pd.DataFrame(rows)


def run_eda() -> dict:
    cfg.FIG_DIR.mkdir(parents=True, exist_ok=True)
    cfg.TABLE_DIR.mkdir(parents=True, exist_ok=True)
    df = load_panel()
    summary = validate_panel(df)

    audit = quality_audit(df)
    audit.to_csv(cfg.TABLE_DIR / "eda_quality_audit.csv", index=False)
    df.describe(include="all").T.to_csv(cfg.TABLE_DIR / "eda_describe.csv")

    # segment tables
    tenure = pd.cut(df["tenure_months"], [0, 3, 12, 24, 100],
                    labels=["0-3 mo", "4-12 mo", "13-24 mo", "24+ mo"])
    by_plan = df.groupby("plan_type")[cfg.TARGET].mean().reindex(["Basic", "Standard", "Premium"])
    by_tenure = df.groupby(tenure, observed=True)[cfg.TARGET].mean()
    pd.concat({"plan_type": by_plan, "tenure_cohort": by_tenure}).rename("churn_rate") \
        .to_csv(cfg.TABLE_DIR / "eda_segment_churn.csv")
    monthly = df.groupby(cfg.DATE_COL)[cfg.TARGET].mean()

    # ---- Figure: univariate ------------------------------------------------
    fig, axes = plt.subplots(2, 2, figsize=(11, 8))
    sns.histplot(df["tenure_months"], bins=30, color=TEAL, ax=axes[0, 0], edgecolor="white")
    axes[0, 0].set_title("Tenure (months): right-skewed", fontweight="bold", color=NAVY)
    sns.histplot(df["watch_hours"].dropna(), bins=30, color=TEAL, ax=axes[0, 1], edgecolor="white")
    axes[0, 1].set_title("Monthly watch hours", fontweight="bold", color=NAVY)
    sns.boxplot(x=df["support_tickets_30d"].dropna(), color=TEAL, ax=axes[1, 0],
                flierprops=dict(markerfacecolor=ORANGE, markeredgecolor=ORANGE, markersize=3))
    axes[1, 0].set_title("Support tickets: outliers flagged", fontweight="bold", color=NAVY)
    miss = audit.set_index("column")["missing_pct"]
    miss = miss[miss > 0].sort_values()
    axes[1, 1].barh(miss.index, miss.values, color=ORANGE)
    axes[1, 1].set_title("Missing values (%)", fontweight="bold", color=NAVY)
    for ax in axes.ravel():
        _clean(ax)
    fig.suptitle("Univariate analysis", fontsize=15, fontweight="bold", color=NAVY)
    fig.tight_layout()
    fig.savefig(cfg.FIG_DIR / "eda_univariate.png", dpi=200)
    plt.close(fig)

    # ---- Figure: churn by segment + monthly trend ----------------------------
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.6))
    axes[0].bar(by_plan.index, by_plan.values * 100, color=[NAVY, TEAL, ORANGE])
    axes[0].axhline(df[cfg.TARGET].mean() * 100, ls="--", color=GREY)
    axes[0].set(title="Churn rate by plan", ylabel="Monthly churn (%)")
    axes[1].bar(by_tenure.index.astype(str), by_tenure.values * 100, color=[ORANGE, ORANGE, TEAL, NAVY])
    axes[1].set(title="Churn rate by tenure cohort")
    axes[2].plot(monthly.index.strftime("%b %y"), monthly.values * 100, "o-", color=TEAL, lw=2.4)
    axes[2].axhline(monthly.iloc[:7].mean() * 100, ls="--", color=GREY, label="Pre-event average")
    axes[2].set(title="Monthly churn rate")
    axes[2].tick_params(axis="x", rotation=45)
    axes[2].legend()
    for ax in axes:
        _clean(ax)
        ax.title.set_fontweight("bold")
        ax.title.set_color(NAVY)
    fig.tight_layout()
    fig.savefig(cfg.FIG_DIR / "eda_churn_segments_trend.png", dpi=200)
    plt.close(fig)

    # ---- Figure: bivariate / multivariate ------------------------------------
    fig, axes = plt.subplots(1, 2, figsize=(13, 5))
    sns.boxplot(data=df, x="churned", y="engagement_trend", palette=[TEAL, ORANGE], ax=axes[0],
                showfliers=False, hue="churned", legend=False)
    axes[0].set_xticks([0, 1], ["Retained", "Churned"])
    axes[0].set(xlabel="", title="Engagement trend vs. churn")
    corr = df[cfg.NUMERIC_FEATURES + cfg.BINARY_FEATURES + [cfg.TARGET]].corr()
    sns.heatmap(corr, cmap="vlag", center=0, annot=True, fmt=".2f", annot_kws={"size": 7.5},
                cbar_kws={"shrink": 0.8}, ax=axes[1])
    axes[1].set_title("Correlation matrix")
    for ax in axes:
        ax.title.set_fontweight("bold")
        ax.title.set_color(NAVY)
    fig.tight_layout()
    fig.savefig(cfg.FIG_DIR / "eda_bivariate_multivariate.png", dpi=200)
    plt.close(fig)

    summary["churn_by_plan"] = {k: float(v) for k, v in by_plan.items()}
    summary["churn_by_tenure"] = {str(k): float(v) for k, v in by_tenure.items()}
    return summary


if __name__ == "__main__":
    print(run_eda())
