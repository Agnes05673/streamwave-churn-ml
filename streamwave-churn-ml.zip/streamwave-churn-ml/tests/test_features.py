import numpy as np
import pandas as pd

from churn import config as cfg
from churn.features import QuantileClipper, build_preprocessor, feature_names


def test_preprocessor_removes_all_nans(small_panel):
    pre = build_preprocessor()
    out = pre.fit_transform(small_panel[cfg.FEATURES])
    assert not np.isnan(np.asarray(out)).any()


def test_feature_names_match_output_width(small_panel):
    pre = build_preprocessor()
    out = pre.fit_transform(small_panel[cfg.FEATURES])
    assert len(feature_names(pre)) == out.shape[1]


def test_missing_indicators_are_created(small_panel):
    pre = build_preprocessor()
    pre.fit(small_panel[cfg.FEATURES])
    assert any(n.endswith("__was_missing") for n in feature_names(pre))


def test_unseen_category_does_not_crash(small_panel):
    pre = build_preprocessor().fit(small_panel[cfg.FEATURES])
    row = small_panel[cfg.FEATURES].iloc[[0]].copy()
    row["plan_type"] = "Enterprise"
    assert pre.transform(row).shape[0] == 1


def test_clipper_caps_outliers_using_training_quantiles_only():
    train = pd.DataFrame({"x": list(range(1000))})
    clip = QuantileClipper(0.0, 0.99).fit(train)
    capped = clip.transform(pd.DataFrame({"x": [5, 10_000]}))
    assert capped[0, 0] == 5
    assert capped[1, 0] < 1000  # capped at the training 99th percentile, not left at 10,000


def test_clipper_passes_nan_through():
    clip = QuantileClipper().fit(pd.DataFrame({"x": [1.0, 2.0, 3.0, np.nan]}))
    assert np.isnan(clip.transform(pd.DataFrame({"x": [np.nan]}))).all()
