import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from churn import data  # noqa: E402


@pytest.fixture(scope="session")
def small_panel():
    """A small but realistic panel; fast enough for unit tests."""
    return data.generate_panel(n_initial=1500, n_months=9, n_new_per_month=100,
                               price_month=5, seed=7)
