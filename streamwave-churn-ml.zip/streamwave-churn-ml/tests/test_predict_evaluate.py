import numpy as np
import pytest
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

from churn import config as cfg
from churn.evaluate import top_fraction_lift
from churn.features import build_preprocessor
from churn.predict import score_subscribers


@pytest.fixture(scope="module")
def tiny_model(small_panel):
    pipe = Pipeline([("pre", build_preprocessor()), ("clf", LogisticRegression(max_iter=1000))])
    return pipe.fit(small_panel[cfg.FEATURES], small_panel[cfg.TARGET])


def test_scoring_is_sorted_and_ranked(small_panel, tiny_model):
    latest = small_panel[small_panel[cfg.DATE_COL] == small_panel[cfg.DATE_COL].max()]
    scored = score_subscribers(latest.drop(columns=[cfg.TARGET]), model=tiny_model, threshold=0.1)
    assert scored["churn_probability"].is_monotonic_decreasing
    assert scored["risk_rank"].tolist() == list(range(1, len(scored) + 1))
    assert ((scored["churn_probability"] >= 0.1).astype(int) == scored["flagged"]).all()
    assert scored["churn_probability"].between(0, 1).all()


def test_top_n_limits_rows(small_panel, tiny_model):
    scored = score_subscribers(small_panel.drop(columns=[cfg.TARGET]), model=tiny_model,
                               threshold=0.1, top_n=25)
    assert len(scored) == 25


def test_scoring_rejects_missing_features(small_panel, tiny_model):
    with pytest.raises(ValueError):
        score_subscribers(small_panel.drop(columns=["tenure_months"]), model=tiny_model, threshold=0.1)


def test_top_fraction_lift_perfect_ranker():
    y = np.array([1, 1, 0, 0, 0, 0, 0, 0, 0, 0])
    proba = np.array([0.9, 0.8, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1])
    r = top_fraction_lift(y, proba, 0.2)
    assert r["churners_caught"] == 2
    assert r["share_of_all_churners_caught"] == 1.0
    assert r["lift_vs_random"] == pytest.approx(5.0)
