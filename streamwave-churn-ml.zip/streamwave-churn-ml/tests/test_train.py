import numpy as np

from churn import config as cfg
from churn.train import choose_threshold, cost_at_threshold, split_by_subscriber


def test_split_never_shares_a_subscriber(small_panel):
    train, test = split_by_subscriber(small_panel)
    assert set(train[cfg.GROUP_COL]).isdisjoint(set(test[cfg.GROUP_COL]))
    assert len(train) + len(test) == len(small_panel)


def test_cost_at_threshold_by_hand():
    y = np.array([1, 1, 0, 0, 0])
    p = np.array([0.9, 0.2, 0.8, 0.1, 0.05])
    # threshold 0.5 -> flags rows 0 and 2: one TP, one FP, one FN (row 1)
    assert cost_at_threshold(y, p, 0.5, cost_fn=60, cost_fp=5) == 60 + 5


def test_threshold_matches_theory_for_calibrated_probabilities():
    """With well-calibrated probabilities the best cutoff is cost_fp / (cost_fp + cost_fn)."""
    rng = np.random.default_rng(0)
    p = rng.beta(1, 15, size=200_000)
    y = (rng.random(p.size) < p).astype(int)
    t, _ = choose_threshold(y, p, cost_fn=60, cost_fp=5)
    assert abs(t - 5 / 65) < 0.03


def test_higher_miss_cost_lowers_threshold():
    rng = np.random.default_rng(1)
    p = rng.beta(1, 15, size=100_000)
    y = (rng.random(p.size) < p).astype(int)
    t_cheap, _ = choose_threshold(y, p, cost_fn=20, cost_fp=5)
    t_costly, _ = choose_threshold(y, p, cost_fn=200, cost_fp=5)
    assert t_costly < t_cheap
