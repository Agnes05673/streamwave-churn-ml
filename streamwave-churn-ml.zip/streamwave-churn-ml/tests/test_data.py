import pandas as pd
import pytest

from churn import config as cfg
from churn import data


def test_panel_passes_validation(small_panel):
    summary = data.validate_panel(small_panel)
    assert summary["duplicate_subscriber_months"] == 0
    assert summary["months"] == 9
    assert 0.01 < summary["churn_rate"] < 0.30


def test_data_is_reproducible():
    a = data.generate_panel(n_initial=200, n_months=4, n_new_per_month=20, price_month=2, seed=1)
    b = data.generate_panel(n_initial=200, n_months=4, n_new_per_month=20, price_month=2, seed=1)
    pd.testing.assert_frame_equal(a, b)


def test_messiness_is_injected(small_panel):
    assert small_panel["watch_hours"].isna().any()
    assert small_panel["support_tickets_30d"].max() >= 20  # implausible outliers exist


def test_price_increase_raises_churn(small_panel):
    monthly = small_panel.groupby(cfg.DATE_COL)[cfg.TARGET].mean().sort_index()
    pre = monthly.iloc[:5].mean()
    assert monthly.iloc[5] > 1.5 * pre


def test_survivors_are_removed_after_churn(small_panel):
    """A subscriber who churned must not appear in any later month."""
    churn_month = small_panel[small_panel[cfg.TARGET] == 1].groupby(cfg.GROUP_COL)[cfg.DATE_COL].min()
    last_seen = small_panel.groupby(cfg.GROUP_COL)[cfg.DATE_COL].max()
    assert (last_seen.loc[churn_month.index] == churn_month).all()


def test_validation_rejects_bad_target(small_panel):
    bad = small_panel.copy()
    bad.loc[0, cfg.TARGET] = 2
    with pytest.raises(ValueError):
        data.validate_panel(bad)


def test_validation_rejects_missing_column(small_panel):
    with pytest.raises(ValueError):
        data.validate_panel(small_panel.drop(columns=["plan_type"]))
